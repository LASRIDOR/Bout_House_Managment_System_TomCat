package BMS.boutHouse.form;

public interface BoutHouseInstance {
}
