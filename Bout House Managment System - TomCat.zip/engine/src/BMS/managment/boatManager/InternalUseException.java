package BMS.managment.boatManager;

public class InternalUseException extends Exception {
    public InternalUseException(){
        super("Internal Use Only");
    }
}
