package BMS.constants;

public class Constants {
    public static final String BOUT_HOUSE_MANAGER = "bout house manager";
    public static final String BOUT_HOUSE_DATA_TYPE = "BoutHouseDataType";
}
